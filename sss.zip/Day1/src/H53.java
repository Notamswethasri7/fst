
import jakarta.servlet.ServletException;
import java.io.PrintWriter;
import java.util.Enumeration;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class H53
 */
public class H53 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public H53() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		out.println("<html><body>");
		out.println("<h1>HTTP Request Headers</h1>");
		out.println("<table border='1'><tr><th>Header Name</th><th>Header Value</th></tr>");
		Enumeration<String>headerNames=request.getHeaderNames();
		 while (headerNames.hasMoreElements()) {
	            String headerName = headerNames.nextElement();
	            String headerValue = request.getHeader(headerName);
	            out.println("<tr><td>" + headerName + "</td><td>" + headerValue + "</td></tr>");
	        }

	        out.println("</table>");
	        out.println("</body></html>");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}