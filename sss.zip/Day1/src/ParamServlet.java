import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class ParamServlet
 */
public class ParamServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ParamServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 response.setContentType("text/html");
	        PrintWriter out = response.getWriter();

	        // Retrieve initialization parameters
	        String databaseUrl = getServletConfig().getInitParameter("databaseUrl");
	        String databaseUser = getServletConfig().getInitParameter("databaseUser");
	        String databasePassword = getServletConfig().getInitParameter("databasePassword");

	        out.println("<html><body>");
	        out.println("<h1>Initialization Parameters</h1>");
	        out.println("<p><strong>Database URL:</strong> " + databaseUrl + "</p>");
	        out.println("<p><strong>Database User:</strong> " + databaseUser + "</p>");
	        out.println("<p><strong>Database Password:</strong> " + databasePassword + "</p>");
	        out.println("</body></html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
