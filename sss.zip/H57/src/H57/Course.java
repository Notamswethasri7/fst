package H57;



public class Course {
    private String cid;
    private String cname;
    private String cdomain;

    public Course(String cid, String cname, String cdomain) {
        this.cid = cid;
        this.cname = cname;
        this.cdomain = cdomain;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public String getCdomain() {
        return cdomain;
    }

    public void setCdomain(String cdomain) {
        this.cdomain = cdomain;
    }
}
