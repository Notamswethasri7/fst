package H57;


import java.util.Optional;

public class CourseAllocation {
    public Optional<Course> getCid(String courseId) {
        if (courseId.equals("1")) {
            return Optional.of(new Course("1", "Java Programming", "Computer Science"));
        }
        else if (courseId.equals("2")) {
            return Optional.of(new Course("2", "Data Structures", "Computer Science"));
        }
        else if (courseId.equals("3")) {
            return Optional.of(new Course("3", "Data Science", "Computer Science"));
        }
        else if (courseId.equals("4")) {
            return Optional.of(new Course("4", "Python", "Computer Science"));
        }
        else if (courseId.equals("5")) {
            return Optional.of(new Course("5", "Artificial Intelligence", "Computer Science"));
        }
        else if (courseId.equals("6")) {
            return Optional.of(new Course("6", "Machine learning", "Computer Science"));
        }
        else if (courseId.equals("7")) {
            return Optional.of(new Course("7", "Deep Learning", "Computer Science"));
        }
        else if (courseId.equals("8")) {
            return Optional.of(new Course("8", "Data Mining", "Computer Science"));
        }
        else if (courseId.equals("9")) {
            return Optional.of(new Course("9", "Web technologies", "Computer Science"));
        }
        else if (courseId.equals("10")) {
            return Optional.of(new Course("10", "Computer Networks", "Computer Science"));
        }
        else if (courseId.equals("11")) {
            return Optional.of(new Course("11", "Cyber security", "Computer Science"));
        }
        else if (courseId.equals("12")) {
            return Optional.of(new Course("12", "Cloud computing", "Computer Science"));
        }
        else if (courseId.equals("13")) {
            return Optional.of(new Course("13", "Software Engineering", "Computer Science"));
        }
        else if (courseId.equals("14")) {
            return Optional.of(new Course("14", "Devops", "Computer Science"));
        }
        else if (courseId.equals("15")) {
            return Optional.of(new Course("15", "DBMS", "Computer Science"));
        }
        else if (courseId.equals("16")) {
            return Optional.of(new Course("16", "Operating System", "Computer Science"));
        }
        else if (courseId.equals("17")) {
            return Optional.of(new Course("17", "Programming in C", "Computer Science"));
        }
        else if (courseId.equals("18")) {
            return Optional.of(new Course("18", "Oops through C++", "Computer Science"));
        }
        else if (courseId.equals("19")) {
            return Optional.of(new Course("19", "Information technology", "Computer Science"));
        }
        else if (courseId.equals("20")) {
            return Optional.of(new Course("20", "Human Computer Interaction", "Computer Science"));
        }
        return Optional.empty();
    }
}
