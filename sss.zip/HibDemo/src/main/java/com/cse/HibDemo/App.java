package com.cse.HibDemo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml");
        
        // Creating session factory object
        SessionFactory factory = cfg.buildSessionFactory();
        
        // Opening session
        Session session = factory.openSession();
        
        // Creating transaction object
        Transaction t = session.beginTransaction();
        
        // Inserting a new student record (you can comment this if not needed)
        Students s = new Students();
        s.setRno(7);
        s.setBrn("cst");
        s.setName("xyz");
        
        session.persist(s);
        
        // Committing the transaction
        t.commit();
        
        
        session.close();
        System.out.println("Successfully saved and displayed the records.");       
    }
}

