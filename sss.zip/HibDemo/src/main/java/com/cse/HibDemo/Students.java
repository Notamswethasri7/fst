package com.cse.HibDemo;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
class Students {

	@Id
	private int rno;
	private String name;
	private String brn;
	
	public int getRno() {
		return rno;
	}
	public void setRno(int rno) {
		this.rno = rno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBrn() {
		return brn;
	}
	public void setBrn(String brn) {
		this.brn = brn;
	}

}
