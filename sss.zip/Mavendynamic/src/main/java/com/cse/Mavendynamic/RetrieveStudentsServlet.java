package com.cse.Mavendynamic;
import java.io.IOException;
import java.util.List;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

@WebServlet("/RetrieveStudentsServlet")
public class RetrieveStudentsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Default constructor
    public RetrieveStudentsServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
        Session session = factory.getCurrentSession();

        try {
            session.beginTransaction();
            // Query to get all students
            Query<Student> query = session.createQuery("from Student", Student.class);
            List<Student> studentList = query.getResultList();
            session.getTransaction().commit();

            // Debug: Check the size of the retrieved list
            System.out.println("Number of students retrieved: " + studentList.size());

            // Set the student list as a request attribute
            request.setAttribute("students", studentList);
            // Forward the request to displayStudents.jsp
            RequestDispatcher dispatcher = request.getRequestDispatcher("displayStudents.jsp");
            dispatcher.forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            factory.close();
        }
    }
}