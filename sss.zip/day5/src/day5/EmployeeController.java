package day5;

import java.util.*;

public class EmployeeController {
    private Employee model;
    private EmployeeView view;
    public EmployeeController(Employee model, EmployeeView view) {
        this.model=model;
        this.view = view;
    }
    public void setEmployeeId(int eid) {
        model.setEid(eid);
    }

    public void setEmployeeName(String ename) {
        model.setEname(ename);
    }

    public void setEmployeeDepartment(String edepartment) {
        model.setEdepartment(edepartment);
    }
    public int getEmployeeId() {
        return model.getEid();
    }

    public String getEmployeeName() {
        return model.getEname();
    }

    public String getEmployeeDepartment() {
        return model.getEdepartment();
    }
    public void printDetails() {
        view.printView(model.getEid(), model.getEname(), model.getEdepartment());
    }
    public void update() {
        Scanner sc=new Scanner(System.in);      
        System.out.print("Enter new Employee ID: ");
        int newId = sc.nextInt();
        sc.nextLine(); 
        System.out.print("Enter new Employee Name: ");
        String newName = sc.nextLine();
        System.out.print("Enter new Employee Department: ");
        String newDepartment = sc.nextLine();
        model.setEid(newId);
        model.setEname(newName);
        model.setEdepartment(newDepartment);
        System.out.println("Employee details updated successfully!");
    }
}
