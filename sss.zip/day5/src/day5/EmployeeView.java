package day5;

public class EmployeeView {
	 public void printView(int eid, String ename, String edepartment) {
	        System.out.println("Employee Details:");
	        System.out.println("Employee ID: " + eid);
	        System.out.println("Employee Name: " + ename);
	        System.out.println("Employee Department: " + edepartment);
	    }
}
