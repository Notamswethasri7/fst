package day5;

public class MVCDemo {

    public static void main(String[] args) {
        EmployeeView view=new EmployeeView();
        Employee model=retrieveEmpObject();
        EmployeeController controller = new EmployeeController(model, view);
        controller.setEmployeeId(101);
        controller.setEmployeeName("Swetha");
        controller.setEmployeeDepartment("Software Engineer");
        controller.printDetails();
        controller.update();
        controller.printDetails();
    }
    private static Employee retrieveEmpObject() {
        Employee employee=new Employee();
        employee.setEid(101);
        employee.setEname("Default Name");
        employee.setEdepartment("Default Department");
        return employee;
    }
}
