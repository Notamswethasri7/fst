// LoginBean.java
package day6;

public class LoginBean {
    private String username;
    private String password;

    // Getter and Setter methods for username
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    // Getter and Setter methods for password
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    // Validate method to check credentials
    public boolean Validate() {
        return "Admin".equals(username) && "Admin@123".equals(password);
    }
}
