import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/AddStudent")
public class AddStudent extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // JDBC URL, username, and password for MySQL
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/csec";
    private static final String JDBC_USER = "root"; // Replace with your MySQL username
    private static final String JDBC_PASS = "Swetha*sri7"; // Replace with your MySQL password

    // Handles POST requests (form submissions)
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Get the form data from the request
        String rno = request.getParameter("rno");  // Changed to String
        String name = request.getParameter("name");
        int age = Integer.parseInt(request.getParameter("age"));
        double cgpa = Double.parseDouble(request.getParameter("cgpa"));

        try {
            // Load the MySQL driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish a connection to the database
            Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);

            // SQL command to insert data into the student table
            String sql = "INSERT INTO student (rno, name, age, cgpa) VALUES (?, ?, ?, ?)";

            // Create a PreparedStatement object to execute the SQL command
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, rno);  // Set rno as String
            stmt.setString(2, name);
            stmt.setInt(3, age);
            stmt.setDouble(4, cgpa);

            // Execute the SQL command
            int rowsInserted = stmt.executeUpdate();

            if (rowsInserted > 0) {
                out.println("Student registered successfully!");
            } else {
                out.println("Failed to register student.");
            }

            // Clean up
            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            out.println("Error: " + e.getMessage());
        } finally {
            out.close();
        }
    }

    // Handles GET requests (e.g., accessing the servlet directly)
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Redirect to the form page
        response.sendRedirect("ind.html");
    }
}
