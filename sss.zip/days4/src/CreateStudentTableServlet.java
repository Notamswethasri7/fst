import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/CreateStudentTableServlet")
public class CreateStudentTableServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // JDBC URL, username, and password for MySQL
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/csec";
    private static final String JDBC_USER = "root"; // Replace with your MySQL username
    private static final String JDBC_PASS = "Swetha*sri7"; // Replace with your MySQL password

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            // Load the MySQL driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish a connection to the database
            Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);

            // Create a statement object to execute SQL commands
            Statement stmt = conn.createStatement();

            // SQL command to create the student table
            String sql = "CREATE TABLE student (" +
                    "rno VARCHAR(20) PRIMARY KEY, " + // Updated to VARCHAR
                    "name VARCHAR(100) NOT NULL, " +
                    "age INT NOT NULL, " +
                    "cgpa DECIMAL(3, 2) NOT NULL" +
                    ")";

            // Execute the SQL command
            stmt.executeUpdate(sql);

            out.println("Table 'student' created successfully!");

            // Clean up
            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            out.println("Error: " + e.getMessage());
        } finally {
            out.close();
        }
    }
}
