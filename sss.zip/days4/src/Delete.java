import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/Delete")
public class Delete extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // JDBC URL, username, and password for MySQL
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/csec";
    private static final String JDBC_USER = "root"; // Replace with your MySQL username
    private static final String JDBC_PASS = "Swetha*sri7"; // Replace with your MySQL password

    // Handles POST requests (form submissions)
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Get the Roll Number from the request
        String rno = request.getParameter("rno");

        try {
            // Load the MySQL driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish a connection to the database
            Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);

            // SQL command to delete the student record based on Roll Number
            String sql = "DELETE FROM student WHERE rno = ?";

            // Create a PreparedStatement object to execute the SQL command
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, rno);

            // Execute the SQL command
            int rowsDeleted = stmt.executeUpdate();

            if (rowsDeleted > 0) {
                out.println("Student deleted successfully!");
            } else {
                out.println("No student found with Roll Number: " + rno);
            }

            // Clean up
            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            out.println("Error: " + e.getMessage());
        } finally {
            out.close();
        }
    }

    // Handles GET requests (e.g., accessing the servlet directly)
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Redirect to the delete form page
        response.sendRedirect("del.html");
    }
}
