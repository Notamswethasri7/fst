import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ManageStudentServlet")
public class ManageStudentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // JDBC URL, username, and password for MySQL
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/csec";
    private static final String JDBC_USER = "root"; // Replace with your MySQL username
    private static final String JDBC_PASS = "Swetha*sri7"; // Replace with your MySQL password

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Retrieve rno from request
        String rno = request.getParameter("rno");

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            // Load the MySQL driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish a connection to the database
            conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);

            if (rno != null && !rno.isEmpty()) {
                // SQL command to check if the record exists
                String sql = "SELECT * FROM student WHERE rno = ?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, rno);
                rs = pstmt.executeQuery();

                if (rs.next()) {
                    // Record exists, show update form
                    out.println("<html><body>");
                    out.println("<h2>Update Student Details</h2>");
                    out.println("<form action='ManageStudentServlet' method='post'>");
                    out.println("<input type='hidden' name='rno' value='" + rno + "'>");
                    out.println("<label for='name'>Name:</label>");
                    out.println("<input type='text' id='name' name='name' value='" + rs.getString("name") + "' required><br><br>");
                    out.println("<label for='age'>Age:</label>");
                    out.println("<input type='number' id='age' name='age' value='" + rs.getInt("age") + "' required><br><br>");
                    out.println("<label for='cgpa'>CGPA:</label>");
                    out.println("<input type='number' step='0.01' id='cgpa' name='cgpa' value='" + rs.getDouble("cgpa") + "' required><br><br>");
                    out.println("<input type='submit' value='Update'>");
                    out.println("</form>");
                    out.println("</body></html>");
                } else {
                    // Record does not exist
                    out.println("<html><body>");
                    out.println("<h2>No record found with Roll Number: " + rno + "</h2>");
                    out.println("<form action='ManageStudentServlet' method='get'>");
                    out.println("<label for='rno'>Enter Roll Number:</label>");
                    out.println("<input type='text' id='rno' name='rno' required><br><br>");
                    out.println("<input type='submit' value='Check'>");
                    out.println("</form>");
                    out.println("</body></html>");
                }
            } else {
                // Display initial form to enter rno
                out.println("<html><body>");
                out.println("<h2>Enter Roll Number to Update</h2>");
                out.println("<form action='ManageStudentServlet' method='get'>");
                out.println("<label for='rno'>Roll Number:</label>");
                out.println("<input type='text' id='rno' name='rno' required><br><br>");
                out.println("<input type='submit' value='Check'>");
                out.println("</form>");
                out.println("</body></html>");
            }
        } catch (Exception e) {
            e.printStackTrace();
            out.println("<html><body><h3>Error: " + e.getMessage() + "</h3></body></html>");
        } finally {
            // Clean up resources
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            out.close();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Retrieve form parameters
        String rno = request.getParameter("rno");
        String name = request.getParameter("name");
        int age = Integer.parseInt(request.getParameter("age"));
        double cgpa = Double.parseDouble(request.getParameter("cgpa"));

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Load the MySQL driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish a connection to the database
            conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);

            // SQL command to update the student record
            String sql = "UPDATE student SET name = ?, age = ?, cgpa = ? WHERE rno = ?";
            pstmt = conn.prepareStatement(sql);

            // Set parameters
            pstmt.setString(1, name);
            pstmt.setInt(2, age);
            pstmt.setDouble(3, cgpa);
            pstmt.setString(4, rno);

            // Execute the update
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                out.println("<html><body><h2>Record updated successfully!</h2></body></html>");
            } else {
                out.println("<html><body><h2>No record found with Roll Number: " + rno + "</h2></body></html>");
            }
        } catch (Exception e) {
            e.printStackTrace();
            out.println("<html><body><h3>Error: " + e.getMessage() + "</h3></body></html>");
        } finally {
            // Clean up resources
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            out.close();
        }
    }
}
