import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/Showtable")
public class Showtable extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // JDBC URL, username, and password for MySQL
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/csec";
    private static final String JDBC_USER = "root"; // Replace with your MySQL username
    private static final String JDBC_PASS = "Swetha*sri7"; // Replace with your MySQL password

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            // Load the MySQL driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish a connection to the database
            Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);

            // Create a statement object to execute SQL commands
            Statement stmt = conn.createStatement();

            // SQL command to retrieve all records from the student table
            String sql = "SELECT * FROM student";
            ResultSet rs = stmt.executeQuery(sql);

            // Generate HTML table
            out.println("<html><body>");
            out.println("<h2>Student Table</h2>");
            out.println("<table border='1'>");
            out.println("<tr><th>Roll Number</th><th>Name</th><th>Age</th><th>CGPA</th></tr>");

            while (rs.next()) {
                out.println("<tr>");
                out.println("<td>" + rs.getString("rno") + "</td>");
                out.println("<td>" + rs.getString("name") + "</td>");
                out.println("<td>" + rs.getInt("age") + "</td>");
                out.println("<td>" + rs.getDouble("cgpa") + "</td>");
                out.println("</tr>");
            }

            out.println("</table>");
            out.println("</body></html>");

            // Clean up
            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            out.println("<html><body><h3>Error: " + e.getMessage() + "</h3></body></html>");
        } finally {
            out.close();
        }
    }
}
