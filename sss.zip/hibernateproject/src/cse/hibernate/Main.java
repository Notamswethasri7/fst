package cse.hibernate;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class Main {
    public static void main(String[] args) {
        // Configuring Hibernate
        Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml");
        
        // Creating session factory object
        SessionFactory factory = cfg.buildSessionFactory();
        
        // Opening session
        Session session = factory.openSession();
        
        // Creating transaction object
        Transaction t = session.beginTransaction();
        
        // Inserting a new student record (you can comment this if not needed)
        StudentInfo s = new StudentInfo();
        s.setRno(6);
        s.setName("tyngu");
        session.persist(s);
        
        // Committing the transaction
        t.commit();
        
        // Retrieving all student records from the STUDENT_1 table
        Query<StudentInfo> query = session.createQuery("from StudentInfo", StudentInfo.class);
        List<StudentInfo> students = query.list();
        
        // Displaying the student records in a table-like format
        System.out.println("-------------------------------------------------");
        System.out.printf("%-10s %-20s%n", "Roll Number", "Name");
        System.out.println("-------------------------------------------------");
        
        for (StudentInfo student : students) {
            System.out.printf("%-10d %-20s%n", student.getRno(), student.getName());
        }
        
        System.out.println("-------------------------------------------------");
        
        // Closing the session
        session.close();
        System.out.println("Successfully saved and displayed the records.");
    }
}
