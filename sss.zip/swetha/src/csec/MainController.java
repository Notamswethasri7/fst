package csec;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 * Servlet implementation class MainController
 */
public class MainController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MainController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		int roll=Integer.parseInt(request.getParameter("roll"));
//		String name=request.getParameter("name");
//		Student s=new Student();
//		s.setRoll(roll);
//		s.setName(name);
//		Configuration c=new Configuration();
//		c.configure("hibernate.cfg.xml");
//		SessionFactory sf=c.buildSessionFactory();
//		Session ss=sf.openSession();
//		Transaction t=ss.beginTransaction();
//		ss.persist(s);
//		t.commit();
//		ss.close();
		Long roll=Long.parseLong(request.getParameter("roll"));
		Configuration c=new Configuration();
		c.configure("hibernate.cfg.xml");
		SessionFactory sf=c.buildSessionFactory();
		Session ss=sf.openSession();
		Transaction t=ss.beginTransaction();
		Student s=(Student)ss.get(Student.class,roll);
		t.commit();
	    if(s!=null)
	    {
	    	RequestDispatcher r=request.getRequestDispatcher("/Sucess.jsp");
	    	request.setAttribute("student",s);
		    r.forward(request, response);
	    }
	    else
	    {
	    	RequestDispatcher r=request.getRequestDispatcher("/Error.jsp");
			r.include(request, response);
	    }
	}

}