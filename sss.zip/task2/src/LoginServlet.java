import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Cookie;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private static final String USERNAME = "user";
    private static final String PASSWORD = "password";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Check if the user is already logged in by looking for the "auth" cookie
        Cookie[] cookies = request.getCookies();
        boolean isAuthenticated = false;

        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("auth".equals(cookie.getName()) && "true".equals(cookie.getValue())) {
                    isAuthenticated = true;
                    break;
                }
            }
        }

        if (isAuthenticated) {
            out.println("<html><body>");
            out.println("<h1>Welcome back!</h1>");
            out.println("<p>You are already logged in.</p>");
            out.println("</body></html>");
        } else {
            out.println("<html><body>");
            out.println("<h1>Login</h1>");
            out.println("<form method='POST' action='login'>");
            out.println("Username: <input type='text' name='username'><br>");
            out.println("Password: <input type='password' name='password'><br>");
            out.println("<input type='submit' value='Login'>");
            out.println("</form>");
            out.println("</body></html>");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve user credentials from the request
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Validate user credentials
        if (USERNAME.equals(username) && PASSWORD.equals(password)) {
            // Create an authentication cookie
            Cookie authCookie = new Cookie("auth", "true");
            authCookie.setMaxAge(30 * 60); // Set cookie to expire in 30 minutes
            response.addCookie(authCookie);

            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<html><body>");
            out.println("<h1>Login Successful</h1>");
            out.println("<p>Welcome, " + username + "!</p>");
            out.println("</body></html>");
        } else {
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<html><body>");
            out.println("<h1>Login Failed</h1>");
            out.println("<p>Invalid username or password.</p>");
            out.println("<a href='login'>Try again</a>");
            out.println("</body></html>");
        }
    }
}
