
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Servlet implementation class Taskh52
 */
public class Taskh52 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Taskh52() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 response.setContentType("text/html");
	        PrintWriter out = response.getWriter();

	        // Get the current session, creating one if it does not exist
	        HttpSession session = request.getSession(true); // 'true' means create a new session if it doesn't exist

	        // Get session creation time and last access time
	        long creationTime = session.getCreationTime();
	        long lastAccessedTime = session.getLastAccessedTime();

	        // Convert times to readable format
	        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	        String creationTimeStr = dateFormat.format(new Date(creationTime));
	        String lastAccessedTimeStr = dateFormat.format(new Date(lastAccessedTime));

	        out.println("<html><body>");
	        out.println("<h1>Session Information</h1>");
	        out.println("<p>Session ID: " + session.getId() + "</p>");
	        out.println("<p>Session Creation Time: " + creationTimeStr + "</p>");
	        out.println("<p>Last Accessed Time: " + lastAccessedTimeStr + "</p>");
	        out.println("</body></html>");
	}
  
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
